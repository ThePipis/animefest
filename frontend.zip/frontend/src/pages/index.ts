// Centralización de todos los imports de páginas
export { default as AdminAnimes } from './AdminAnimes';
export { AnimeDetail } from './AnimeDetail';
export { Catalogo } from './Catalogo';
export { Episodio } from './Episodio';
export { Favoritos } from './Favoritos';
export { Historial } from './Historial';
export { Login } from './Login';
export { Register } from './Register';
export { Watch } from './Watch';