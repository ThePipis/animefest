export interface User {
  id: number;
  username: string;
  email: string;
  // Agrega más campos si tu backend los envía
}
